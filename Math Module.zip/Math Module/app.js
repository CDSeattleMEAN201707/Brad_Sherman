var mathlib = require('./mathlib')();
console.log(mathlib);
console.log(mathlib.add(5,5));
console.log(mathlib.multiply(5,5));
console.log(mathlib.square(5));
console.log(mathlib.random(1,10));
