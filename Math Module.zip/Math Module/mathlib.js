module.exports = function(){
  return {
    add: function(num1, num2) {
         var result = num1 + num2;
         return result;
    },
    multiply: function(num1, num2) {
         var result = num1 * num2;
         return result;
    },
    square: function(num) {
         var result = num * num;
         return result;
    },
    random: function(num1, num2) {
         var result = Math.floor(Math.random() * (num2 - num1) + num1);
         return result;
    }
  }
};
