var mongoose = require('mongoose');
var uniqueValidator = require('mongoose-unique-validator');
var bcrypt = require('bcrypt');

var userSchema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    unique: true
  },
  first_name:  {
    type: String, required: [true, "First Name is required."],
    minLength: [3, "First Name must be more than 3 characters."]
  },
  last_name: {
    type: String, required: [true, "Last Name is required."],
    minLength: [3, "Last Name must be more than 3 characters."]
  },
  password: {
    type: String, required: [true, "Password is required."],
    minLength: [3, "Password must be more than 3 characters."],
  },
  birthday: {
    type: Date,
    required: true
  }
}, {timestamps: true});

userSchema.plugin(uniqueValidator);

userSchema.methods.hashPassword = function(password)
{
  return bcrypt.hashSync(password, bcrypt.genSaltSync(8));
}

userSchema.pre('save', function(done)
{
  this.password = this.hashPassword(this.password);
  done();
});

var User = mongoose.model("User", userSchema);
