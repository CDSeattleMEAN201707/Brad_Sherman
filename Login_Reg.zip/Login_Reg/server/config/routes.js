var mongoose = require('mongoose');
var User = mongoose.model("User");
var users = require('../controllers/users.js')
var bcrypt = require('bcrypt');

module.exports = function(app)
{
  app.get('/', function(req, res) {
      res.render('index');
  })

  app.get('/welcome', function(req, res) {
      res.render('welcome', {name: req.session.firstname});
  })

  app.get('/loginPage', function(req, res) {
      res.render('login');
  })

  app.get('/logout', function(req, res) {
      req.session.destroy();
      res.redirect('/');
  })

  app.post('/register', function(req, res) {
      if (req.body.password != req.body.passwordconfirm)
      {
          res.render('index', {error: 'Typed passwords do not match.'})
      }
      else
      {
        var newUser = new User({email: req.body.email, first_name: req.body.firstname,
        last_name: req.body.firstname, password: req.body.password, birthday: req.body.birthday});
        newUser.save(function(err)
        {
          if(err)
          {
            res.render('index', {title: 'Errors!!!', errors: newUser.errors})
          }
          else
          {
            req.session.name = req.body.firstname;
            res.render('welcome', {name: req.session.name});
          }

        });
      }
  });

  app.post('/login', function(req, res) {
      var hashedPassword = bcrypt.hashSync(req.body.password, bcrypt.genSaltSync(8));
      console.log(hashedPassword);
      console.log(req.body.email)
      User.findOne({email: req.body.email}, function(err, user)
        {
          if(user == null)
          {
            res.render('login', {error: 'Invalid email address'});
          }
          else if (!bcrypt.compareSync(req.body.password, user.password))
          {
            res.render('login', {error: 'Incorrect Password.'});
          }
          else
          {
            req.session.name = user.first_name;
            res.render('welcome', {name: req.session.name});
          }
        });
  });
}
