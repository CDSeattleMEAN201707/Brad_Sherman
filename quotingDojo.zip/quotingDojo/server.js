var express = require('express');
var app = express();
var mongoose = require('mongoose');
var bodyParser = require('body-parser');

mongoose.connect('mongodb://localhost/quotingDojo');

var UserSchema = new mongoose.Schema({
  name: { type: String, required: true },
  quote: { type: String, required: true }
}, { timestamps: true });

var User = mongoose.model('User', UserSchema);

mongoose.model('User', UserSchema);

app.use(bodyParser.urlencoded({ extended: true }));

var path = require('path');

app.use(express.static(path.join(__dirname, './static')));
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');

app.get('/', function(req, res) {
    res.render('index');
})

app.get('/quotes', function(req, res) {
    User.find({}, function(err, users)
    {
      res.render('quotes', {title: "Users", users: users});
    });

})

app.post('/quotes', function(req, res) {
    console.log("POST DATA", req.body);
    var newUser = new User({name: req.body.name, quote: req.body.quote});
    newUser.save(function(err)
    {
      if(err)
      {
        res.render('index', {title: 'Errors!!!', errors: newUser.errors})
      }
      else
      {
        res.redirect('/quotes');
      }
    });
})

app.listen(8000, function() {
    console.log("listening on port 8000");
})
