var express = require('express');
var app = express();
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
var Schema = mongoose.Schema;

var postSchema = new mongoose.Schema({
  name: {type: String, required: true},
  message: {type: String, required: true},
  comments: [{type: Schema.Types.ObjectId, ref: 'Comment'}]
}, {timestamps: true});

var commentSchema = new mongoose.Schema({
  _post: {type: Schema.Types.ObjectId, ref: 'Post'},
  name: {type: String, required: true},
  comment: {type: String, required: true},
}, {timestamps: true});

var Post = mongoose.model("Post", postSchema);
var Comment = mongoose.model("Comment", commentSchema);

mongoose.connect('mongodb://localhost/parrotDashboard');

app.use(bodyParser.urlencoded({ extended: true }));

var path = require('path');

app.use(express.static(path.join(__dirname, './static')));
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');

app.get('/', function(req, res) {
    Post.find({}).populate('comments').exec(function(err, posts)
      {
        res.render('index', {posts: posts});
      });

})

app.post('/postmessage', function(req, res) {
    var newPost = new Post({name: req.body.name, message: req.body.message});
    newPost.save(function(err)
    {
      if(err)
      {
        res.render('index', {title: 'Errors!!!', errors: newPost.errors})
      }
      else
      {
        res.redirect('/');
      }

    });
});

app.post('/postcomment/:id', function(req, res) {
    Post.findOne({_id: req.params.id}, function(err, post)
    {
      var newComment = new Comment({name: req.body.name, comment: req.body.comment});
      newComment._post = post._id;
      newComment.save(function(err)
      {
        post.comments.push(newComment);
        post.save(function(err)
        {
          if(err)
          {
            console.log('Error!!!');
          }
          else
          {
            res.redirect('/');
          }

        });

      });

    });
});


app.listen(8000, function() {
    console.log("listening on port 8000");
})
