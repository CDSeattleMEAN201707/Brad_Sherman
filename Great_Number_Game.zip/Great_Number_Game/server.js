var express = require("express");
var session = require('express-session');
var path = require("path");

var app = express();
var bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "./static")));
app.use(session({secret: 'passwordispassword'}));

app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');

// ARROW FUNCTIONS?

app.get('/', function(req, res)
{
  if(req.session.number == null)
  {
    req.session.number = Math.floor(Math.random() * 100) + 1;
  }
  if(req.session.result != null)
  {
    var result = req.session.result;
  }
  console.log(req.session.number);
  res.render("index", {results: result});
});

app.post('/guess', function(req, res)
{
  if(req.body.guess < req.session.number)
  {
    req.session.result = "Low";
  }
  else if(req.body.guess > req.session.number)
  {
    req.session.result = "High";
  }
  else
  {
    req.session.result = "Win";
  }
  res.redirect("/");
});

app.get('/reset', function(req, res)
{
  req.session.destroy();
  res.redirect("/");
});

app.listen(8000, function() {
 console.log("listening on port 8000");
});
